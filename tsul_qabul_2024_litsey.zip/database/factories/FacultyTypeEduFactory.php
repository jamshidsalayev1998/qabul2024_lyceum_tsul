<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\FacultyTypeEdu;
use Faker\Generator as Faker;

$factory->define(FacultyTypeEdu::class, function (Faker $faker) {
    return [
        //
    ];
});
