<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Edutype;
use Faker\Generator as Faker;

$factory->define(Edutype::class, function (Faker $faker) {
    return [
        //
    ];
});
