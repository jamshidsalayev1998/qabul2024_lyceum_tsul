<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Editing;
use Faker\Generator as Faker;

$factory->define(Editing::class, function (Faker $faker) {
    return [
        //
    ];
});
