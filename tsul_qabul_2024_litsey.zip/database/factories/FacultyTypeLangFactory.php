<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\FacultyTypeLang;
use Faker\Generator as Faker;

$factory->define(FacultyTypeLang::class, function (Faker $faker) {
    return [
        //
    ];
});
