<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Languagetype;
use Faker\Generator as Faker;

$factory->define(Languagetype::class, function (Faker $faker) {
    return [
        //
    ];
});
