<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Endegree;
use Faker\Generator as Faker;

$factory->define(Endegree::class, function (Faker $faker) {
    return [
        //
    ];
});
