<?php

namespace App;

use App\FacultyTypeLang;
use App\Edutype;
use App\Languagetype;
use App\FacultyTypeEdu;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;

class HighSchoolDocumentEnable extends Model
{
    protected $table = 'high_school_document_enables';

}
