<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Uff extends Model
{
    protected $table = 'uff';
}
